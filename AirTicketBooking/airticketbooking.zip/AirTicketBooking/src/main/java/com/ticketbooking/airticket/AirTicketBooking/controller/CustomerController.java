package com.ticketbooking.airticket.AirTicketBooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.bind.annotation.PathVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ticketbooking.airticket.AirTicketBooking.dal.CustomerRepository;
import com.ticketbooking.airticket.AirTicketBooking.model.Customer;

@SuppressWarnings("unused")
@RestController
@RequestMapping(value = "/")
public class CustomerController {

	private final Logger LOG = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private CustomerRepository customerRepository;

//	public CustomerController(CustomerRepository customerRepository) {
//		this.customerRepository = customerRepository;
//	}

	@RequestMapping(value = "/bookTicket", method = RequestMethod.POST)
	// @PostMapping("book-ticket")
	public Customer newTicket(@RequestBody Customer customer) {
		LOG.info("Saving user.");
		return customerRepository.save(customer);
	}
	
	@RequestMapping(value = "/cancelTicket", method = RequestMethod.POST)
	// @PostMapping("book-ticket")
	public Customer newTicket(@RequestBody Customer customer) {
		LOG.info("Saving user.");
		return customerRepository.save(customer);
	}
	
	
	
	

}
