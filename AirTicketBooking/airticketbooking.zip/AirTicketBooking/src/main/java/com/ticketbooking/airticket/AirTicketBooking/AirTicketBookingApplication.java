package com.ticketbooking.airticket.AirTicketBooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirTicketBookingApplication { 

	public static void main(String[] args) {
		SpringApplication.run(AirTicketBookingApplication.class, args);
	}
}
