package com.ticketbooking.airticket.AirTicketBooking.dal;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import com.ticketbooking.airticket.AirTicketBooking.model.Customer;


@Component
public interface CustomerRepository extends MongoRepository<Customer,String>{
//public interface CustomerRepository extends CrudRepository<Customer, String>{
	
}
